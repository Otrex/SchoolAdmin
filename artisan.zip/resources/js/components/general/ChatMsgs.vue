<template>
<div>
    <h1>Here Are some CHats</h1>
</div>
</template>

<script>
export default {
    name: 'ChatMsgs',
    props: {
        msg: String
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->

<style scoped>

</style>
